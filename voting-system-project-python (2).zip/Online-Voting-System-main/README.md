# Online Voting System
 It is a desktop application made with socket programming in Python. It uses synchronous multithreading. 
 
![image](https://user-images.githubusercontent.com/63534263/137679993-4bca517b-93d2-4f96-8127-8dd5fb21648d.png)

Admin Login Credentials - 
UserId - Admin
Password - admin

![image](https://user-images.githubusercontent.com/63534263/137680091-890f3f81-7d40-47bb-92a9-586af7689ece.png)

Admin can now run the server, and the voters are now eligible to register themselves.
Admin has the power to check the total vote count.

![image](https://user-images.githubusercontent.com/63534263/137680282-af60434f-e9e9-480b-83ee-c59e5fa77fc1.png) 
![image](https://user-images.githubusercontent.com/63534263/137680312-7ad69187-46a6-4d1f-bb09-5356dfa713d2.png)

Now the voter can register himself/herself with their unique ID - Aadhar Number.

![image](https://user-images.githubusercontent.com/63534263/137680656-1701e4ae-385b-4f2f-b894-f2bcaa1717ef.png)

![image](https://user-images.githubusercontent.com/63534263/137680695-b90cf7c1-5202-4e54-b3bc-9b9d83b99ae5.png)

Now the voter can login with its given credentials and caste vote.

![image](https://user-images.githubusercontent.com/63534263/137680857-e420b360-5ff0-4425-9ef7-8b81c1795e22.png)
![image](https://user-images.githubusercontent.com/63534263/137680895-c19b55d5-7851-4585-9491-15c9d00cba57.png)
![image](https://user-images.githubusercontent.com/63534263/137681090-fb89bbcc-b6b2-47e9-b86e-1e2c94472fe9.png)

Now, the admin can have a check on the total votes.
![image](https://user-images.githubusercontent.com/63534263/137681164-a2af0160-649b-4cce-938e-78415cf9e2b5.png)

